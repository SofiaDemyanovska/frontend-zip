export enum KeyChars {
    Ctrl = "Control",
    ArrowRight = "ArrowRight",
    ArrowLeft = "ArrowLeft",
    Space = " ",
    Tab = "Tab",
}
