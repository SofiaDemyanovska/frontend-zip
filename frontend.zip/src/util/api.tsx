import axios from "axios";

export default axios.create({
  baseURL: `site_urlapi/`,
});
