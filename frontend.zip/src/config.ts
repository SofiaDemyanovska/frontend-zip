interface IConfigType {
    urlApi: string;
}

const config: IConfigType = {
    urlApi: "http://localhost:5000/",
};

export default config;
