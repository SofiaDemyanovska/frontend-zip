interface IConfigType {
    urlApi: string;
}

const config: IConfigType = {
    urlApi: "site_url",
};

export default config;
