const aux = (props: any) => props.children;

export default aux;
